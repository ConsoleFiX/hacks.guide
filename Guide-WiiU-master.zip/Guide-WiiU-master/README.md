# Wii U Hacks Guide

Nintendo Wii U homebrew guide written by staff members of the [Nintendo Homebrew Discord server.](https://discord.gg/C29hYvh)

[The guide can be found here!](https://wiiu.hacks.guide/)
