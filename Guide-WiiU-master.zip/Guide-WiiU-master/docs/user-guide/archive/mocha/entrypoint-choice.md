# Archive - Mocha - Choose An Entrypoint

!> **THE METHODS DESCRIBED IN THIS PAGE ARE NO LONGER SUPPORTED**  
**CURRENT METHOD IS AVAILABLE [HERE](../../introduction)**

## Online Exploit

- Requires an Internet connection every time you want to launch the Homebrew Launcher.

### [**Continue with the Online Exploit**](online-exploit/sd-preparation) {docsify-ignore}

## Indexiine

- Requires an Internet connection for the setup process but can be used offline once it's been setup.
- Requires you to modify a system file.

### [**Continue with Indexiine**](indexiine/sd-preparation) {docsify-ignore}