# Uninstall Indexiine
---
This page will guide through the process of uninstalling Indexiine from your Wii U.

### Instructions {docsify-ignore}

1. Launch the Homebrew Launcher.
1. Launch Indexiine-Installer.
1. Press the B button to uninstall Indexiine.
1. Check that your Wii U no longer automatically launches the Homebrew Launcher upon entering the Internet browser.
