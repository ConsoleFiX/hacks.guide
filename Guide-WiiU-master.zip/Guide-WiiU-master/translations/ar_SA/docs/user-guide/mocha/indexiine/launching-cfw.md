# Mocha - Indexiine

## Launching CFW {docsify-ignore}

Unlike systems such as the DSi, Wii, or 3DS, Wii U CFW is temporary. This means that as soon as your system reboots, you will lose CFW and have to follow these instructions again. This can be skipped by installing CBHC to a Haxchi CFW installation.

### Instructions {docsify-ignore}

1. Launch the Homebrew Launcher by launching the Internet Browser.
1. Navigate the Homebrew Launcher and open the Mocha CFW app.
1. It will take you back to the Homebrew Launcher and enable CFW.
1. You will need to re-do these steps every reboot to launch CFW.