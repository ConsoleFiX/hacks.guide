# Donations {docsify-ignore-all}
---
> [![Paypal](https://raw.githubusercontent.com/hacks-guide/Guide-WiiU/master/docs/assets/img/paypal_white.png#center)](https://paypal.me/NintendoHomebrew)
  <embed>
    <center>
        <a href="https://paypal.me/NintendoHomebrew" target="_blank">https://paypal.me/NintendoHomebrew</a>
    </center>
</embed>
