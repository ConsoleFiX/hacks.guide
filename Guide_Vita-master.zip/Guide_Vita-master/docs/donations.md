---
title: "Donations"
ads: false
sidebar: false
---

### emiyl

<a href="https://emiyl.com/paypal" target="_blank" style="padding: 1em;"><img src="/assets/images/paypal_white.png" alt="PayPal"/></a>
<p style="text-align: center;">emiyl.com/paypal</p>