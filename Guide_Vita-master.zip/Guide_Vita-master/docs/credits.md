---
title: "Credits"
sidebar: false
---

::: tip
Special thanks to all of [the translators](https://crowdin.com/project/vita-guide) for being awesome!
:::

<div>
  <div class="credits">
    <div class="user">
      <img src="https://github.com/emiyl.png">
    </div>
    <div class="user">
      <h3>emiyl</h3>
      <p>Emma</p>
      <a class="social-icon" href="https://twitter.com/emiyl0" target="_blank">
        <i class="fab fa-twitter"></i>
      </a>
      <a class="social-icon" href="https://github.com/emiyl" target="_blank">
        <i class="fab fa-github"></i>
      </a>
    </div>
  </div>
</div>

<br>

If we forgot you here, contact us and we'll add your name.

    + Plailect
    + CelesteBlue
    + codestation
    + Davee
    + mmozeiko
    + motoharu
    + Proxima
    + TheFloW
    + xyz
    + YifanLu
    + SKGleba
    + takoyaki99
    + Cimmerian-Iter
  
