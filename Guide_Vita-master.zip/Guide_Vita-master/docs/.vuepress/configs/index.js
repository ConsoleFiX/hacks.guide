module.exports = {
	en_US: require('./en_US')
};