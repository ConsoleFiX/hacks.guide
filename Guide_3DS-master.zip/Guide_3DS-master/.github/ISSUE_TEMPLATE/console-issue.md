---
name: Console Issue
about: Some issue with your console after/during following the guide?
---

**System model**

<!--Your console model, eg. Old 3DS, New 3DS, 2DS-->

**Firmware version**

<!--Your console system version, you can check this in System Settings-->

**Luma3DS Version(If applicable)**

<!--If you have Luma3DS installed, your Luma3DS version-->

**Guide Section(If applicable)**

<!--Section of the guide you had this issue-->